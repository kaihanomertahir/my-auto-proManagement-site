# CampLet Pro Final

Open `index.html` locally or publish this folder to GitHub Pages. Use the purple **نشر GitHub/Firebase** button inside the app to paste Firebase config and optionally publish to GitHub with your own token.

A browser-only HTML file cannot create a GitHub token or complete Google-login-to-GitHub automatically for security reasons. It can publish after you paste a valid token.
